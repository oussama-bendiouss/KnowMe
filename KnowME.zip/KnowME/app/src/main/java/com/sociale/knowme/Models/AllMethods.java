package com.sociale.knowme.Models;

public class AllMethods {
    public static String  name = "" ;
}
